import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { QuizCard } from "@/components/QuizCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Trophy, RotateCcw, Sparkles, BookOpen } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Difficulty } from "@shared/schema";

interface GeneratedQuiz {
  question: string;
  options: string[];
  correctAnswer: string;
  topic: string;
  difficulty: Difficulty;
}

interface QuizSubmitResponse {
  isCorrect: boolean;
  xpGained: number;
  user: {
    xp: number;
    level: number;
    streak: number;
    badges: string[];
  };
}

export default function QuizPage() {
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState<Difficulty>("medium");
  const [currentQuiz, setCurrentQuiz] = useState<GeneratedQuiz | null>(null);
  const [score, setScore] = useState(0);
  const [totalAnswered, setTotalAnswered] = useState(0);
  const [totalXPEarned, setTotalXPEarned] = useState(0);
  const [hasAnswered, setHasAnswered] = useState(false);
  const [lastResult, setLastResult] = useState<boolean | null>(null);

  const generateQuizMutation = useMutation<GeneratedQuiz, Error, { topic: string; difficulty: Difficulty }>({
    mutationFn: ({ topic, difficulty }) =>
      apiRequest<GeneratedQuiz>("POST", "/api/quiz/generate", { topic, difficulty }),
    onSuccess: (data) => {
      setCurrentQuiz(data);
      setHasAnswered(false);
      setLastResult(null);
    },
  });

  const submitQuizMutation = useMutation<QuizSubmitResponse, Error, { question: string; options: string[]; correctAnswer: string; userAnswer: string; topic: string; difficulty: Difficulty }>({
    mutationFn: (data) =>
      apiRequest<QuizSubmitResponse>("POST", "/api/quiz/submit", data),
    onSuccess: (data) => {
      if (data.isCorrect) {
        setScore(score + 1);
      }
      setTotalAnswered(totalAnswered + 1);
      setTotalXPEarned(totalXPEarned + data.xpGained);
      queryClient.invalidateQueries({ queryKey: ["/api/progress/stats"] });
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
    },
  });

  const handleStartQuiz = () => {
    if (!topic.trim()) return;
    generateQuizMutation.mutate({ topic: topic.trim(), difficulty });
  };

  const handleAnswer = async (answer: string, isCorrect: boolean) => {
    if (!currentQuiz || hasAnswered) return;
    
    setHasAnswered(true);
    setLastResult(isCorrect);

    await submitQuizMutation.mutateAsync({
      question: currentQuiz.question,
      options: currentQuiz.options,
      correctAnswer: currentQuiz.correctAnswer,
      userAnswer: answer,
      topic: currentQuiz.topic,
      difficulty: currentQuiz.difficulty,
    });
  };

  const handleNext = () => {
    if (!currentQuiz) return;
    generateQuizMutation.mutate({ topic: currentQuiz.topic, difficulty: currentQuiz.difficulty });
  };

  const handleRestart = () => {
    setCurrentQuiz(null);
    setScore(0);
    setTotalAnswered(0);
    setTotalXPEarned(0);
    setHasAnswered(false);
    setLastResult(null);
    setTopic("");
  };

  const accuracy = totalAnswered > 0 ? Math.round((score / totalAnswered) * 100) : 0;

  if (!currentQuiz) {
    return (
      <div className="h-full flex items-center justify-center p-8">
        <Card className="max-w-lg w-full">
          <CardHeader className="text-center">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <BookOpen className="w-8 h-8 text-primary" />
              </div>
            </div>
            <CardTitle className="text-3xl font-display">Start a Quiz</CardTitle>
            <p className="text-muted-foreground mt-2">
              Choose a topic and difficulty to begin your adaptive learning journey
            </p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="topic">Topic</Label>
              <Input
                id="topic"
                value={topic}
                onChange={(e) => setTopic(e.target.value)}
                placeholder="e.g., Mathematics, Science, History..."
                data-testid="input-topic"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="difficulty">Difficulty</Label>
              <Select value={difficulty} onValueChange={(value) => setDifficulty(value as Difficulty)}>
                <SelectTrigger data-testid="select-difficulty">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="easy">Easy</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button 
              onClick={handleStartQuiz} 
              className="w-full" 
              disabled={!topic.trim() || generateQuizMutation.isPending}
              data-testid="button-start-quiz"
            >
              {generateQuizMutation.isPending ? (
                <>Generating Quiz...</>
              ) : (
                <>
                  <Sparkles className="w-5 h-5 mr-2" />
                  Generate Quiz
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="border-b border-border p-6">
        <div className="max-w-2xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-display font-bold text-foreground">{currentQuiz.topic}</h1>
              <p className="text-sm text-muted-foreground capitalize">{currentQuiz.difficulty} Difficulty</p>
            </div>
            <Button variant="outline" onClick={handleRestart} data-testid="button-end-quiz">
              End Quiz
            </Button>
          </div>
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Score: {score}/{totalAnswered}</span>
              <span className="text-muted-foreground">Accuracy: {accuracy}%</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 flex items-center justify-center p-8">
        {generateQuizMutation.isPending ? (
          <div className="text-center space-y-2">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
            <p className="text-muted-foreground">Generating next question...</p>
          </div>
        ) : (
          <QuizCard
            question={currentQuiz.question}
            options={currentQuiz.options}
            correctAnswer={currentQuiz.correctAnswer}
            difficulty={currentQuiz.difficulty}
            onAnswer={handleAnswer}
          />
        )}
      </div>

      {hasAnswered && (
        <div className="border-t border-border p-6">
          <div className="max-w-2xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-3">
              {lastResult ? (
                <div className="flex items-center gap-2 text-green-700 dark:text-green-400">
                  <div className="w-8 h-8 rounded-full bg-green-500/10 flex items-center justify-center">
                    ✓
                  </div>
                  <span className="font-semibold">Correct!</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-red-700 dark:text-red-400">
                  <div className="w-8 h-8 rounded-full bg-red-500/10 flex items-center justify-center">
                    ✗
                  </div>
                  <span className="font-semibold">Incorrect</span>
                </div>
              )}
              <span className="text-sm text-muted-foreground">
                +{submitQuizMutation.data?.xpGained || 0} XP
              </span>
            </div>
            <Button onClick={handleNext} data-testid="button-next-question">
              Next Question
            </Button>
          </div>
        </div>
      )}

      <div className="border-t border-border p-4">
        <div className="max-w-2xl mx-auto flex justify-between items-center text-sm">
          <span className="text-muted-foreground">
            Total XP Earned: <span className="font-semibold text-primary">+{totalXPEarned}</span>
          </span>
        </div>
      </div>
    </div>
  );
}
