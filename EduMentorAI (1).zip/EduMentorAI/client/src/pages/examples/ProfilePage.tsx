import ProfilePage from "../ProfilePage";

export default function ProfilePageExample() {
  return <ProfilePage />;
}
