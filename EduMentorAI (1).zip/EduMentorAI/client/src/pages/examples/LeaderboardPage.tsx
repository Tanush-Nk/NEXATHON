import LeaderboardPage from "../LeaderboardPage";

export default function LeaderboardPageExample() {
  return <LeaderboardPage />;
}
