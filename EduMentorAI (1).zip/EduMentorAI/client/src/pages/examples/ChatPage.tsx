import ChatPage from "../ChatPage";

export default function ChatPageExample() {
  return <ChatPage />;
}
