import QuizPage from "../QuizPage";

export default function QuizPageExample() {
  return <QuizPage />;
}
