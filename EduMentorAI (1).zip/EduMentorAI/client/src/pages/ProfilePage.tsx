import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { XPDisplay } from "@/components/XPDisplay";
import { BadgeGrid } from "@/components/BadgeGrid";
import { StreakTracker } from "@/components/StreakTracker";
import { Award, BookOpen, Target, TrendingUp, Edit, Calendar } from "lucide-react";
import type { User, Quiz, Badge } from "@shared/schema";

export default function ProfilePage() {
  const { data: user, isLoading: userLoading } = useQuery<User>({
    queryKey: ["/api/users/current"],
  });

  const { data: quizzes, isLoading: quizzesLoading } = useQuery<Quiz[]>({
    queryKey: ["/api/quizzes"],
  });

  if (userLoading || quizzesLoading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center space-y-2">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
          <p className="text-muted-foreground">Loading profile...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="h-full flex items-center justify-center">
        <p className="text-muted-foreground">User not found</p>
      </div>
    );
  }

  const completedQuizzes = quizzes?.filter(q => q.isCorrect !== null) || [];
  const correctAnswers = completedQuizzes.filter(q => q.isCorrect).length;
  const accuracy = completedQuizzes.length > 0 
    ? Math.round((correctAnswers / completedQuizzes.length) * 100)
    : 0;

  const activityDays = quizzes
    ?.map(q => new Date(q.timestamp))
    .filter((date, index, self) => 
      self.findIndex(d => d.toDateString() === date.toDateString()) === index
    ) || [];

  return (
    <div className="h-full overflow-auto">
      <div className="max-w-6xl mx-auto p-8 space-y-8">
        {/* Profile Header */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-center gap-6">
              <Avatar className="w-32 h-32">
                <AvatarFallback className="text-4xl font-display font-bold bg-primary text-primary-foreground">
                  {user.username.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 text-center md:text-left space-y-2">
                <div className="flex items-center gap-3 justify-center md:justify-start">
                  <h1 className="text-3xl font-display font-bold text-foreground">
                    {user.username}
                  </h1>
                  <Button variant="outline" size="sm" data-testid="button-edit-profile">
                    <Edit className="w-4 h-4" />
                  </Button>
                </div>
                <p className="text-lg text-muted-foreground">Level {user.level} Learner</p>
                <div className="flex flex-wrap gap-2 justify-center md:justify-start">
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    Member since {new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                  </div>
                </div>
              </div>

              <XPDisplay xp={user.xp} level={user.level} size="lg" />
            </div>
          </CardContent>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="pt-6 text-center space-y-2">
              <Award className="w-8 h-8 text-primary mx-auto" />
              <p className="text-3xl font-display font-bold text-foreground" data-testid="text-total-xp">
                {user.xp.toLocaleString()}
              </p>
              <p className="text-sm text-muted-foreground">Total XP</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center space-y-2">
              <BookOpen className="w-8 h-8 text-primary mx-auto" />
              <p className="text-3xl font-display font-bold text-foreground" data-testid="text-quizzes">
                {completedQuizzes.length}
              </p>
              <p className="text-sm text-muted-foreground">Quizzes</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center space-y-2">
              <Target className="w-8 h-8 text-primary mx-auto" />
              <p className="text-3xl font-display font-bold text-foreground" data-testid="text-accuracy">
                {accuracy}%
              </p>
              <p className="text-sm text-muted-foreground">Accuracy</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6 text-center space-y-2">
              <TrendingUp className="w-8 h-8 text-primary mx-auto" />
              <p className="text-3xl font-display font-bold text-foreground" data-testid="text-streak">
                {user.streak}
              </p>
              <p className="text-sm text-muted-foreground">Day Streak</p>
            </CardContent>
          </Card>
        </div>

        {/* Achievements and Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h2 className="text-2xl font-display font-semibold text-foreground mb-6">Achievements</h2>
              <BadgeGrid badges={user.badges as Badge[]} />
            </div>

            {completedQuizzes.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-xl">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {completedQuizzes.slice(0, 5).map((quiz) => (
                    <div
                      key={quiz.id}
                      className="flex items-center justify-between p-3 rounded-lg border border-border"
                      data-testid={`activity-${quiz.id}`}
                    >
                      <div className="flex-1">
                        <p className="font-medium text-foreground line-clamp-1">{quiz.question}</p>
                        <p className="text-sm text-muted-foreground">{quiz.topic} • {quiz.difficulty}</p>
                      </div>
                      {quiz.isCorrect ? (
                        <div className="px-3 py-1 rounded-full bg-green-500/10 text-green-700 dark:text-green-400 text-sm font-medium">
                          ✓ Correct
                        </div>
                      ) : (
                        <div className="px-3 py-1 rounded-full bg-red-500/10 text-red-700 dark:text-red-400 text-sm font-medium">
                          ✗ Incorrect
                        </div>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>

          <div>
            <StreakTracker
              currentStreak={user.streak}
              bestStreak={user.streak}
              activityDays={activityDays}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
